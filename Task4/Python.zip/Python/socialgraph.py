from person import Person


class SocialGraph(object):

    def __init__(self):
        self.central_person = Person('YOU')

    def iterate_nodes(self):
        """Access all the people of the social graph one by one."""
        # Implement your iterator with yield here.
        # Each yield statement should return one Person object.
        pass
